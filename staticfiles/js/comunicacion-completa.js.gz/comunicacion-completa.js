// =====================================================
// SISTEMA WALKIE-TALKIE COMPLETO - VERSIÓN CORREGIDA
// ✅ CON SOPORTE PARA UBICACIONES EN TIEMPO REAL
// =====================================================
console.log('🚀 LOADING comunicacion-completa.js - VERSIÓN CON CREACIÓN AUTOMÁTICA DE MARCADORES v2.1');
console.log('✅✅✅ VERIFICACIÓN: Si ves este mensaje, el código NUEVO está cargado ✅✅✅');
console.log('📅 Timestamp de carga:', new Date().toISOString());

// Variables globales
let map;
let socket;
let chatSocket;  // WebSocket para chat
let driverMarkers = {};
let audioContext;
let audioQueue = [];
let isPlayingAudio = false;
let mediaRecorderCentral;
let centralAudioStream;
let Maps_API_KEY;

// Variables de reconexión WebSocket
let wsReconnectAttempts = 0;
let wsMaxReconnectAttempts = 10;
let wsReconnectInterval = 1000;
let wsReconnectTimeout;
let isConnecting = false;  // Bandera para evitar múltiples instancias
let reconnectTimeout = null;  // Timeout de reconexión

// Variables del sistema walkie-talkie
let pendingAudioQueue = [];
let dismissedAudios = new Set();
let currentPlayingAudio = null;

const roomName = "conductores";
const wsProtocol = window.location.protocol === "https:" ? "wss://" : "ws://";

// Elementos del DOM - se inicializarán después de que el DOM esté listo
let startCentralMicBtn = null;
let stopCentralMicBtn = null;

// Flag para asegurar que solo se inicialice una vez
let systemInitialized = false;
let domReady = false;

// DEBUGGING INICIAL
console.log('🔍 Estado inicial del DOM:', document.readyState);
console.log('🔍 URL actual:', window.location.href);

// Función súper segura para obtener elementos
function safeGetElement(id, retries = 3) {
    console.log(`🔍 Buscando elemento: ${id} (${retries} reintentos)`);
    for (let i = 0; i < retries; i++) {
        try {
            const element = document.getElementById(id);
            if (element) {
                console.log(`✅ Elemento encontrado: ${id} - Tipo:`, element.constructor.name);
                return element;
            } else {
                console.warn(`❌ Elemento ${id} no encontrado en intento ${i + 1}`);
            }
        } catch (error) {
            console.warn(`⚠️ Error buscando elemento ${id}, intento ${i + 1}:`, error);
        }

        if (i < retries - 1) {
            // Esperar un poco antes del siguiente intento
            setTimeout(() => { }, 100);
        }
    }
    return null;
}

// Función para crear elementos faltantes
function ensureRequiredElements() {
    console.log('🔧 Verificando y creando elementos requeridos...');

    const requiredElements = {
        'connection-status': 'div',
        'audio-log': 'div',
        'audio-player': 'audio',
        'record-audio-btn': 'button'
    };

    for (const [id, tagName] of Object.entries(requiredElements)) {
        let element = document.getElementById(id);
        if (!element) {
            console.log(`⚠️ Creando elemento faltante: ${id}`);
            element = document.createElement(tagName);
            element.id = id;

            // Configuraciones específicas según el tipo
            if (id === 'audio-player') {
                element.controls = false;
                element.autoplay = false;
                element.style.display = 'none';
            }

            document.body.appendChild(element);
            console.log(`✅ Elemento ${id} creado`);
        }
    }
}

// Función súper robusta para actualizar estado
function updateStatus(message, className = 'connected') {
    console.log('🔄 updateStatus llamado:', message, className);
    try {
        const elements = ['connection-status', 'system-status', 'status'];
        let found = false;

        for (const id of elements) {
            const el = document.getElementById(id);
            if (el) {
                el.textContent = message;

                // Actualizar clase si el elemento lo soporta
                if (el.className !== undefined) {
                    el.className = className;
                }

                found = true;
                console.log('✅ Estado actualizado en:', id);
                break;
            }
        }

        if (!found) {
            console.warn('⚠️ Ningún elemento de estado encontrado');
        }
    } catch (error) {
        console.warn('⚠️ Error en updateStatus (ignorado):', error.message);
    }
}

// Actualizar estado de conexión basado en ambos WebSockets
function updateConnectionStatus() {
    const audioConnected = socket && socket.readyState === WebSocket.OPEN;
    const chatConnected = chatSocket && chatSocket.readyState === WebSocket.OPEN;

    console.log('🔍 Estado WebSockets - Audio:', audioConnected, 'Chat:', chatConnected);

    // Actualizar indicador visual en el header
    const statusIndicator = document.querySelector('.status-indicator span');
    const statusDot = document.querySelector('.status-dot');

    if (audioConnected && chatConnected) {
        if (statusIndicator) statusIndicator.textContent = 'Conectado a Central';
        if (statusDot) {
            statusDot.style.background = '#4CAF50';
            statusDot.style.animation = 'pulse 2s infinite';
        }
        console.log('✅ Sistema completamente conectado');
    } else if (audioConnected || chatConnected) {
        if (statusIndicator) statusIndicator.textContent = 'Conexión Parcial';
        if (statusDot) {
            statusDot.style.background = '#FFC107';
            statusDot.style.animation = 'pulse 1s infinite';
        }
        console.log('⚠️ Conexión parcial');
    } else {
        if (statusIndicator) statusIndicator.textContent = 'Desconectado';
        if (statusDot) {
            statusDot.style.background = '#F44336';
            statusDot.style.animation = 'none';
        }
        console.log('❌ Sistema desconectado');
    }
}

// Configurar Google Maps con carga de conductores
async function loadGoogleMapsAPI() {
    try {
        // Verificar si ya se cargó para evitar duplicados
        if (window.google && window.google.maps) {
            console.log('⚠️ Google Maps ya cargado');
            initMap();
            return;
        }

        // Obtener API key
        const response = await fetch('/api/maps-key/');
        const data = await response.json();
        Maps_API_KEY = data.maps_api_key;

        if (!Maps_API_KEY) {
            console.error('❌ No se pudo obtener la API key de Google Maps');
            return;
        }

        console.log('✅ API key obtenida, cargando Google Maps...');

        const script = document.createElement('script');
        script.src = `https://maps.googleapis.com/maps/api/js?key=${Maps_API_KEY}&callback=initMap`;
        script.async = true;
        script.defer = true;
        script.onerror = function () {
            console.error('❌ Error cargando Google Maps API');
        };
        document.head.appendChild(script);

    } catch (error) {
        console.error('❌ Error configurando Google Maps:', error);
    }
}

// Función global para inicializar Google Maps
window.initMap = function () {
    console.log('🗺️ Inicializando Google Maps...');

    try {
        const mapContainer = document.getElementById("map");
        if (!mapContainer) {
            console.warn('⚠️ Contenedor del mapa no encontrado');
            return;
        }

        map = new google.maps.Map(mapContainer, {
            zoom: 14,
            center: { lat: -2.170998, lng: -79.922359 },
            mapTypeId: 'roadmap'
        });

        console.log('✅ Mapa inicializado correctamente');
        updateStatus('Mapa cargado', 'connected');

        // Cargar ubicaciones de taxis
        loadTaxiLocations();

        // Actualizar ubicaciones cada 30 segundos
        setInterval(loadTaxiLocations, 30000);

    } catch (error) {
        console.warn('⚠️ Error inicializando mapa:', error.message);
    }
};

// Cargar y mostrar ubicaciones de taxis
async function loadTaxiLocations() {
    try {
        console.log('🚖 Cargando ubicaciones de taxis...');
        const response = await fetch('/api/taxis_ubicacion/');

        if (!response.ok) {
            console.warn('⚠️ Error en respuesta del servidor:', response.status);
            return;
        }

        const taxis = await response.json();
        console.log('📍 Taxis recibidos:', taxis.length);

        updateTaxiMarkers(taxis);

    } catch (error) {
        console.warn('⚠️ Error cargando ubicaciones:', error.message);
    }
}

// Actualizar marcadores de taxis en el mapa
function updateTaxiMarkers(taxis) {
    if (!map) {
        console.warn('⚠️ Mapa no inicializado');
        return;
    }

    try {
        // Limpiar marcadores existentes
        Object.values(driverMarkers).forEach(marker => {
            if (marker && typeof marker.setMap === 'function') {
                marker.setMap(null);
            }
        });
        driverMarkers = {};

        // Agregar nuevos marcadores
        taxis.forEach(taxi => {
            if (taxi.latitude && taxi.longitude) {
                const position = {
                    lat: parseFloat(taxi.latitude),
                    lng: parseFloat(taxi.longitude)
                };

                const marker = new google.maps.Marker({
                    position: position,
                    map: map,
                    title: `Conductor: ${taxi.nombre_conductor || 'Sin nombre'}`,
                    icon: {
                        url: '/static/imagenes/logo1.png',
                        scaledSize: new google.maps.Size(24, 24),
                        origin: new google.maps.Point(0, 0),
                        anchor: new google.maps.Point(12, 12)
                    }
                });

                // Ventana de información
                const infoWindow = new google.maps.InfoWindow({
                    content: `
                        <div style="color: #333 !important; background: white !important; padding: 10px; min-width: 200px;">
                            <h5 style="color: #2c3e50 !important; margin: 0 0 10px 0; font-size: 16px; font-weight: bold;">${taxi.nombre_conductor || 'Sin nombre'}</h5>
                            <p style="color: #34495e !important; margin: 5px 0;"><strong style="color: #2c3e50 !important;">Placa:</strong> ${taxi.placa || 'N/A'}</p>
                            <p style="color: #34495e !important; margin: 5px 0;"><strong style="color: #2c3e50 !important;">Estado:</strong> ${taxi.disponible ? '✅ Disponible' : '🚗 Ocupado'}</p>
                            <p style="color: #34495e !important; margin: 5px 0;"><strong style="color: #2c3e50 !important;">Teléfono:</strong> ${taxi.telefono || 'N/A'}</p>
                            <button onclick="openDriverChat(${taxi.id})" style="background: #007bff !important; color: white !important; border: none; padding: 8px 16px; border-radius: 4px; cursor: pointer; margin-top: 10px; font-weight: bold;">
                                💬 Chat
                            </button>
                        </div>
                    `
                });

                marker.addListener('click', () => {
                    // Cerrar otras ventanas
                    Object.values(driverMarkers).forEach(m => {
                        if (m.infoWindow) {
                            m.infoWindow.close();
                        }
                    });

                    infoWindow.open(map, marker);
                });

                marker.infoWindow = infoWindow;
                driverMarkers[taxi.id] = marker;

                // También guardar por username si existe (para actualizaciones de ubicación)
                if (taxi.username) {
                    driverMarkers[taxi.username] = marker;
                    console.log(`🔑 Marcador guardado con username: ${taxi.username}`);
                }
            }
        });

        console.log(`✅ ${Object.keys(driverMarkers).length} marcadores actualizados`);
        updateStatus(`${Object.keys(driverMarkers).length} conductores en línea`, 'connected');

    } catch (error) {
        console.error('❌ Error actualizando marcadores:', error);
    }
}

// Función para abrir chat con conductor
function openDriverChat(driverId) {
    console.log('💬 Abriendo chat con conductor:', driverId);

    try {
        // Buscar el elemento del conductor en la lista
        const driverElement = document.querySelector(`[data-driver-id="${driverId}"]`);
        let driverName = `Conductor #${driverId}`;

        if (driverElement) {
            const nameElement = driverElement.querySelector('span');
            if (nameElement) {
                driverName = nameElement.textContent;
            }
        }

        // Actualizar el header del chat
        const chatHeader = document.getElementById('chat-header');
        if (chatHeader) {
            chatHeader.innerHTML = `
                <span>💬 Chat con: ${driverName}</span>
                <div class="header-controls">
                    <button class="header-toggle-btn" id="toggle-fullscreen" onclick="toggleFullscreen()" title="Pantalla completa (F11)">🔳</button>
                    <button class="header-toggle-btn minimize" onclick="toggleChat()" title="Ocultar chat (Ctrl+H)">✕</button>
                </div>
            `;
        }

        // Limpiar mensajes anteriores y mostrar el chat
        const chatLog = document.getElementById('chat-log');
        if (chatLog) {
            chatLog.innerHTML = `
                <div style="text-align: center; padding: 20px; color: #7f8c8d; border-bottom: 1px solid #eee;">
                    <strong>Iniciando chat con ${driverName}</strong><br>
                    <small>Los mensajes aparecerán aquí...</small>
                </div>
            `;
        }

        // Mostrar el área de entrada de mensaje
        const inputContainer = document.getElementById('chat-input-container');
        if (inputContainer) {
            inputContainer.style.display = 'flex';
        }

        // Ocultar el mensaje de "no chat seleccionado"
        const noChatSelected = document.getElementById('no-chat-selected');
        if (noChatSelected) {
            noChatSelected.style.display = 'none';
        }

        // Configurar el input para este conductor
        const messageInput = document.getElementById('chat-message-input');
        if (messageInput) {
            messageInput.setAttribute('data-driver-id', driverId);
            messageInput.placeholder = `Escribe un mensaje a ${driverName}...`;
            messageInput.focus();
        }

        // Configurar el botón de envío
        const submitButton = document.getElementById('chat-message-submit');
        if (submitButton) {
            // Remover eventos anteriores
            submitButton.replaceWith(submitButton.cloneNode(true));
            const newSubmitButton = document.getElementById('chat-message-submit');

            newSubmitButton.addEventListener('click', function () {
                sendMessageToDriver(driverId);
            });
        }

        // Configurar Enter en el input
        if (messageInput) {
            messageInput.replaceWith(messageInput.cloneNode(true));
            const newInput = document.getElementById('chat-message-input');

            newInput.addEventListener('keypress', function (e) {
                if (e.key === 'Enter') {
                    sendMessageToDriver(driverId);
                }
            });
        }

        // Hacer visible el chat window si está oculto
        const chatWindow = document.querySelector('.chat-window');
        if (chatWindow) {
            chatWindow.classList.remove('hidden');
        }

        console.log(`✅ Chat iniciado con ${driverName} (ID: ${driverId})`);

        // Cargar historial de chat
        loadChatHistory(driverId);

    } catch (error) {
        console.error('❌ Error abriendo chat:', error);
        alert('Error abriendo el chat. Por favor, intenta de nuevo.');
    }
}

// Cargar historial de chat con un conductor
async function loadChatHistory(driverId) {
    try {
        console.log(`📜 Cargando historial de chat con conductor ${driverId}...`);

        // Backend expone /api/chat_history/<id>/ (con guion bajo)
        const response = await fetch(`/api/chat_history/${driverId}/`);
        if (!response.ok) {
            console.warn('⚠️ No se pudo cargar el historial');
            return;
        }

        const payload = await response.json();
        const messages = payload.messages || payload; // compat: algunos endpoints devuelven array directo
        console.log(`✅ Historial cargado: ${messages.length || 0} mensajes`);

        const chatLog = document.getElementById('chat-log');
        if (!chatLog) return;

        // Limpiar chat log
        chatLog.innerHTML = '';

        // Agregar mensajes al chat
        messages.forEach(msg => {
            // El endpoint devuelve timestamp como "HH:MM" (string). Si viene Date, también lo soportamos.
            const isSent = msg.is_sent === true || msg.sender_id == 1; // fallback si backend no envía is_sent
            const timestamp = typeof msg.timestamp === 'string'
                ? msg.timestamp
                : new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

            const messageHtml = `
                <div class="message ${isSent ? 'outgoing' : 'incoming'}" style="margin-bottom: 10px; padding: 8px 12px; background: ${isSent ? '#007bff' : '#e9ecef'}; color: ${isSent ? 'white' : 'black'}; border-radius: 8px; max-width: 70%; ${isSent ? 'margin-left: auto;' : 'margin-right: auto;'}">
                    <strong>${isSent ? 'Central' : msg.sender_name}:</strong> ${msg.message}
                    <div style="font-size: 0.8em; opacity: 0.8;">${timestamp}</div>
                </div>
            `;
            chatLog.insertAdjacentHTML('beforeend', messageHtml);
        });

        // Scroll al final
        chatLog.scrollTop = chatLog.scrollHeight;

    } catch (error) {
        console.error('❌ Error cargando historial:', error);
    }
}

// Función para enviar mensaje a conductor específico
function sendMessageToDriver(driverId) {
    const input = document.getElementById('chat-message-input');
    if (!input || !input.value.trim()) {
        return;
    }

    const message = input.value.trim();
    console.log('📤 Enviando mensaje a conductor:', driverId, message);

    try {
        // Agregar mensaje al chat log inmediatamente
        const chatLog = document.getElementById('chat-log');
        if (chatLog) {
            const timestamp = new Date().toLocaleTimeString();
            const messageHtml = `
                <div class="message outgoing" style="margin-bottom: 10px; padding: 8px 12px; background: #007bff; color: white; border-radius: 8px; max-width: 70%; margin-left: auto;">
                    <strong>Central:</strong> ${message}
                    <div style="font-size: 0.8em; opacity: 0.8;">${timestamp}</div>
                </div>
            `;
            chatLog.insertAdjacentHTML('beforeend', messageHtml);
            chatLog.scrollTop = chatLog.scrollHeight;
        }

        // Enviar por WebSocket de Chat
        if (chatSocket && chatSocket.readyState === WebSocket.OPEN) {
            chatSocket.send(JSON.stringify({
                'message': message,
                'recipient_id': driverId,
                'sender_id': 'admin'
            }));

            console.log('✅ Mensaje enviado por Chat WebSocket');
        } else {
            console.warn('⚠️ Chat WebSocket no disponible - mensaje no enviado');

            // Mostrar error en el chat
            if (chatLog) {
                const errorHtml = `
                    <div style="text-align: center; color: #e74c3c; padding: 10px; font-style: italic;">
                        ⚠️ Error: Sin conexión. Mensaje no enviado.
                    </div>
                `;
                chatLog.insertAdjacentHTML('beforeend', errorHtml);
            }
        }

        // Limpiar input
        input.value = '';

    } catch (error) {
        console.error('❌ Error enviando mensaje:', error);

        // Mostrar error en el chat
        const chatLog = document.getElementById('chat-log');
        if (chatLog) {
            const errorHtml = `
                <div style="text-align: center; color: #e74c3c; padding: 10px; font-style: italic;">
                    ❌ Error enviando mensaje: ${error.message}
                </div>
            `;
            chatLog.insertAdjacentHTML('beforeend', errorHtml);
        }
    }
}

// Función legacy para compatibilidad (mantener pero redirigir)
function sendChatMessage(driverId) {
    console.log('🔄 Redirigiendo sendChatMessage a sendMessageToDriver');
    sendMessageToDriver(driverId);
}

// Configurar WebSocket - CÓDIGO FUNCIONAL DEL CONDUCTOR
function setupWebSocket() {
    // Evitar múltiples llamadas simultáneas
    if (isConnecting) {
        console.log('⚠️ Ya hay una conexión en progreso, ignorando...');
        return;
    }

    // Limpiar timeout de reconexión anterior
    if (reconnectTimeout) {
        clearTimeout(reconnectTimeout);
        reconnectTimeout = null;
    }

    // Cerrar conexiones anteriores si existen
    if (socket && socket.readyState !== WebSocket.CLOSED) {
        console.log('🔌 Cerrando Audio WebSocket anterior...');
        socket.close();
    }
    if (chatSocket && chatSocket.readyState !== WebSocket.CLOSED) {
        console.log('🔌 Cerrando Chat WebSocket anterior...');
        chatSocket.close();
    }

    isConnecting = true;
    console.log('🔌 Iniciando WebSockets (Audio + Chat)...');

    const wsProtocol = window.location.protocol === "https:" ? "wss://" : "ws://";
    const host = window.location.host;

    // 1. Audio WebSocket
    console.log('🔊 Conectando Audio WebSocket...');
    const audioWsUrl = `${wsProtocol}${host}/ws/audio/conductores/`;
    console.log('🔊 URL del Audio WS:', audioWsUrl);
    socket = new WebSocket(audioWsUrl);

    socket.onopen = () => {
        console.log('✅ Audio WS Conectado exitosamente');
        isConnecting = false;
        updateConnectionStatus();
        wsReconnectAttempts = 0;
    };

    socket.onclose = () => {
        console.log('🔊 Audio WS Desconectado');
        isConnecting = false;
        updateConnectionStatus();

        // Reconectar solo si no hay otro timeout pendiente
        if (wsReconnectAttempts < wsMaxReconnectAttempts && !reconnectTimeout) {
            wsReconnectAttempts++;
            console.log(`🔄 Reintentando conexión (${wsReconnectAttempts}/${wsMaxReconnectAttempts})...`);
            reconnectTimeout = setTimeout(() => {
                reconnectTimeout = null;
                setupWebSocket();
            }, wsReconnectInterval * wsReconnectAttempts);
        }
    };

    socket.onerror = (error) => {
        console.error('🔊 Audio WS Error:', error);
        isConnecting = false;
    };

    socket.onmessage = (e) => {
        console.log('🔊 Audio WebSocket recibió mensaje RAW:', e.data.substring(0, 200));
        try {
            const data = JSON.parse(e.data);
            console.log('🔊 Audio WebSocket mensaje parseado:', {
                type: data.type,
                hasAudioData: !!data.audio_data,
                hasAudio: !!data.audio,
                senderId: data.senderId || data.sender_id,
                senderRole: data.senderRole || data.sender_role
            });
            handleWebSocketMessage(data);
        } catch (error) {
            console.error('⚠️ Error procesando mensaje de audio:', error);
        }
    };

    // 2. Chat WebSocket
    console.log('💬 Conectando Chat WebSocket...');
    const chatWsUrl = `${wsProtocol}${host}/ws/chat/`;
    console.log('💬 URL del Chat WS:', chatWsUrl);
    chatSocket = new WebSocket(chatWsUrl);

    chatSocket.onopen = () => {
        console.log('✅ Chat WS Conectado exitosamente');
        updateConnectionStatus();
    };

    chatSocket.onclose = () => {
        console.log('💬 Chat WS Desconectado');
        updateConnectionStatus();

        // Reconectar solo si no hay otro timeout pendiente
        if (!reconnectTimeout) {
            reconnectTimeout = setTimeout(() => {
                reconnectTimeout = null;
                setupWebSocket();
            }, 5000);
        }
    };

    chatSocket.onerror = (error) => {
        console.error('💬 Chat WS Error:', error);
    };

    chatSocket.onmessage = (e) => {
        console.log('💬 Mensaje recibido:', e.data);
        try {
            const data = JSON.parse(e.data);
            handleChatMessage(data);
        } catch (error) {
            console.warn('⚠️ Error procesando mensaje de chat:', error);
        }
    };
}

// Manejar mensajes WebSocket
function handleWebSocketMessage(data) {
    console.log('📨 Procesando mensaje:', data.type);

    switch (data.type) {
        case 'audio_message':
        case 'central_audio':  // Audio de la central a conductores
        case 'audio_broadcast':  // Audio broadcast desde el servidor
            handleAudioMessage(data);
            break;
        case 'chat_message':
            handleChatMessage(data);
            break;
        case 'driver_status':
            handleDriverStatusUpdate(data);
            break;
        case 'location':
        case 'location_update':
        case 'driver_location_update':  // ✅ Agregar soporte para ubicaciones desde app móvil
            handleLocationUpdate(data);
            break;
        default:
            console.log('ℹ️ Tipo de mensaje no manejado:', data.type);
    }
}

// Manejar mensaje de audio
function handleAudioMessage(data) {
    console.log('🎵 Mensaje de audio recibido', data);

    try {
        // Obtener audio_data de diferentes formatos posibles
        const audioData = data.audio_data || data.audio;

        if (audioData) {
            // Determinar el origen del audio
            let sender = 'Desconocido';
            let senderId = 'unknown';

            if (data.type === 'central_audio') {
                // Audio de la central (no debería llegar aquí, pero por si acaso)
                sender = 'Central';
                senderId = 'central';
            } else if (data.senderId || data.sender_id || data.driver_id) {
                // Audio de un conductor
                senderId = data.senderId || data.sender_id || data.driver_id;
                sender = data.senderName || data.sender_name || `Conductor #${senderId}`;
            }

            console.log(`🎵 Reproduciendo audio de: ${sender} (${audioData.length} bytes)`);

            // Reproducir audio inmediatamente usando el mismo método del conductor
            const audioBlob = base64ToBlob(audioData, 'audio/webm');
            const audioUrl = URL.createObjectURL(audioBlob);
            const audio = new Audio(audioUrl);

            audio.play()
                .then(() => {
                    console.log('✅ Audio reproducido correctamente');
                    updateAudioLog(`🔊 Audio de ${sender}`);
                })
                .catch(err => {
                    console.error('❌ Error reproduciendo audio:', err);
                    updateAudioLog(`❌ Error reproduciendo audio de ${sender}`);
                });

        } else {
            console.warn('⚠️ Mensaje de audio sin datos. Keys disponibles:', Object.keys(data));
        }
    } catch (error) {
        console.error('❌ Error procesando audio:', error);
    }
}

// Función helper para convertir base64 a Blob
function base64ToBlob(base64, mimeType) {
    const byteCharacters = atob(base64);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);
    return new Blob([byteArray], { type: mimeType });
}

// Manejar actualización de ubicación en tiempo real
function handleLocationUpdate(data) {
    console.log('📍 Actualización de ubicación recibida:', data);
    console.log('🔍 DEBUG: handleLocationUpdate - Versión con creación automática de marcadores');

    const driverId = data.driverId || data.driver_id;
    const latitude = data.latitude;
    const longitude = data.longitude;
    const source = data.source || 'web';  // 'mobile' o 'web'
    const timestamp = data.timestamp || '';

    if (!driverId || !latitude || !longitude) {
        console.warn('⚠️ Datos de ubicación incompletos:', data);
        return;
    }

    const sourceIcon = source === 'mobile' ? '📱' : '🌐';
    console.log(`${sourceIcon} Ubicación actualizada: ${driverId} (${source}) - ${latitude}, ${longitude}`);
    if (timestamp) {
        console.log(`⏰ Timestamp: ${timestamp}`);
    }

    if (!map) {
        console.warn('⚠️ Mapa no inicializado aún');
        return;
    }

    // Buscar marcador existente (por ID numérico o por username)
    let marker = null;
    let markerKey = null;

    // Primero intentar por ID directo
    if (window.driverMarkers && window.driverMarkers[driverId]) {
        marker = window.driverMarkers[driverId];
        markerKey = driverId;
    } else {
        // Si no existe, buscar por username en los marcadores existentes
        // (Flutter puede enviar username en vez de ID)
        for (const [key, existingMarker] of Object.entries(window.driverMarkers || {})) {
            // Verificar si el marcador tiene info que coincida con el driverId
            if (existingMarker && existingMarker.title && existingMarker.title.toLowerCase().includes(driverId.toLowerCase())) {
                marker = existingMarker;
                markerKey = key;
                console.log(`🔍 Marcador encontrado por username: ${key}`);
                break;
            }
        }
    }

    const newPosition = { lat: parseFloat(latitude), lng: parseFloat(longitude) };

    console.log(`🔍 DEBUG: marker encontrado?`, marker ? 'SÍ' : 'NO');
    console.log(`🔍 DEBUG: window.driverMarkers existe?`, !!window.driverMarkers);
    console.log(`🔍 DEBUG: driverId buscado:`, driverId);

    if (marker) {
        // Actualizar marcador existente
        marker.setPosition(newPosition);
        console.log(`✅ Marcador de ${driverId} actualizado en el mapa (origen: ${source})`);
    } else {
        // Crear nuevo marcador si no existe
        console.log(`🆕 Creando nuevo marcador para ${driverId} (origen: ${source})`);
        console.log(`🔍 DEBUG: Entrando a bloque de creación de marcador`);
        const newMarker = new google.maps.Marker({
            position: newPosition,
            map: map,
            title: `Conductor: ${driverId}`,
            icon: {
                url: '/static/imagenes/logo1.png',
                scaledSize: new google.maps.Size(24, 24),
                origin: new google.maps.Point(0, 0),
                anchor: new google.maps.Point(12, 12)
            }
        });

        // Guardar el marcador (usar driverId como key)
        if (!window.driverMarkers) {
            window.driverMarkers = {};
        }
        window.driverMarkers[driverId] = newMarker;

        // InfoWindow básico
        const infoWindow = new google.maps.InfoWindow({
            content: `
                <div style="color: #333 !important; background: white !important; padding: 10px; min-width: 180px;">
                    <h5 style="color: #2c3e50 !important; margin: 0 0 10px 0; font-size: 16px; font-weight: bold;">${driverId}</h5>
                    <p style="color: #34495e !important; margin: 5px 0;"><strong style="color: #2c3e50 !important;">Origen:</strong> ${source === 'mobile' ? '📱 App Móvil' : '🌐 Web'}</p>
                    <p style="color: #34495e !important; margin: 5px 0;"><strong style="color: #2c3e50 !important;">Ubicación:</strong> ${latitude.toFixed(4)}, ${longitude.toFixed(4)}</p>
                </div>
            `
        });

        newMarker.addListener('click', () => {
            infoWindow.open(map, newMarker);
        });

        console.log(`✅ Marcador creado y agregado al mapa para ${driverId}`);
    }
}

// Manejar mensaje de chat
function handleChatMessage(data) {
    console.log('💬 Mensaje de chat recibido:', data);

    try {
        const chatLog = document.getElementById('chat-log');
        if (!chatLog) {
            console.warn('⚠️ chat-log no encontrado');
            return;
        }

        // Extraer datos del mensaje (compatible con ambos formatos)
        const message = data.message;
        const senderId = data.sender_id || data.driver_id;
        const senderName = data.sender_name || `Conductor #${senderId}`;

        if (!message || !senderId) {
            console.warn('⚠️ Mensaje incompleto:', data);
            return;
        }

        // Solo mostrar mensajes de conductores (no los míos)
        if (senderId == 1) {
            console.log('⏭️ Ignorando mensaje propio');
            return;
        }

        console.log(`✅ Mostrando mensaje de ${senderName}: ${message}`);

        const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        const messageHtml = `
            <div class="message incoming" style="margin-bottom: 10px; padding: 8px 12px; background: #e9ecef; color: black; border-radius: 8px; max-width: 70%; margin-right: auto;">
                <strong>${senderName}:</strong> ${message}
                <div style="font-size: 0.8em; opacity: 0.8;">${timestamp}</div>
            </div>
        `;
        chatLog.insertAdjacentHTML('beforeend', messageHtml);
        chatLog.scrollTop = chatLog.scrollHeight;

        // Remover placeholder si existe
        const placeholder = chatLog.querySelector('div[style*="text-align: center"]');
        if (placeholder) placeholder.remove();

    } catch (error) {
        console.error('❌ Error procesando mensaje de chat:', error);
    }
}

// Configurar sistema de audio
function setupAudioSystem() {
    console.log('🎵 Configurando sistema de audio...');

    try {
        // Configurar AudioContext
        if (window.AudioContext || window.webkitAudioContext) {
            audioContext = new (window.AudioContext || window.webkitAudioContext)();
            console.log('✅ AudioContext creado');
        } else {
            console.warn('⚠️ AudioContext no soportado');
        }

        // Configurar botón de grabación
        setupRecordingButton();

    } catch (error) {
        console.error('❌ Error configurando audio:', error);
    }
}

// Configurar botón de grabación
function setupRecordingButton() {
    const btn = safeGetElement('record-audio-btn');
    if (!btn) {
        console.warn('⚠️ Botón de grabación no encontrado');
        return;
    }

    console.log('✅ Configurando botón de grabación...');

    // Verificar que el elemento soporte eventos
    if (typeof btn.addEventListener === 'function') {
        btn.addEventListener('mousedown', startRecording);
        btn.addEventListener('mouseup', stopRecording);
        btn.addEventListener('mouseleave', stopRecording);
        btn.addEventListener('touchstart', startRecording);
        btn.addEventListener('touchend', stopRecording);

        console.log('✅ Eventos de grabación configurados');
    } else {
        console.warn('⚠️ addEventListener no disponible en botón');
    }
}

// Iniciar grabación
async function startRecording() {
    console.log('🎤 Iniciando grabación...');

    try {
        updateStatus('Grabando...', 'recording');

        // Cambiar estilo del botón
        const btn = safeGetElement('record-audio-btn');
        if (btn && btn.style) {
            btn.style.backgroundColor = '#FF5722';
        }

        // Obtener acceso al micrófono
        centralAudioStream = await navigator.mediaDevices.getUserMedia({ audio: true });

        mediaRecorderCentral = new MediaRecorder(centralAudioStream);
        const audioChunks = [];

        mediaRecorderCentral.ondataavailable = event => {
            audioChunks.push(event.data);
        };

        mediaRecorderCentral.onstop = async () => {
            const audioBlob = new Blob(audioChunks, { type: 'audio/wav' });
            await sendAudioToConductors(audioBlob);
        };

        mediaRecorderCentral.start();
        console.log('✅ Grabación iniciada');

    } catch (error) {
        console.error('❌ Error iniciando grabación:', error);
        updateStatus('Error en grabación', 'error');

        // Restaurar botón
        const btn = safeGetElement('record-audio-btn');
        if (btn && btn.style) {
            btn.style.backgroundColor = '';
        }
    }
}

// Detener grabación
function stopRecording() {
    console.log('🎤 Deteniendo grabación...');

    try {
        if (mediaRecorderCentral && mediaRecorderCentral.state !== 'inactive') {
            mediaRecorderCentral.stop();
        }

        if (centralAudioStream) {
            centralAudioStream.getTracks().forEach(track => track.stop());
        }

        // Restaurar estado
        updateStatus('Listo', 'connected');

        // Restaurar botón
        const btn = safeGetElement('record-audio-btn');
        if (btn && btn.style) {
            btn.style.backgroundColor = '';
        }

        console.log('✅ Grabación detenida');

    } catch (error) {
        console.error('❌ Error deteniendo grabación:', error);
    }
}

// Enviar audio a conductores
async function sendAudioToConductors(audioBlob) {
    try {
        console.log('📤 Enviando audio a conductores...');

        // Convertir a base64
        const reader = new FileReader();
        reader.onload = function () {
            const base64Audio = reader.result.split(',')[1];

            // Enviar por WebSocket
            if (socket && socket.readyState === WebSocket.OPEN) {
                socket.send(JSON.stringify({
                    'type': 'central_audio',
                    'audio_data': base64Audio,
                    'room_name': roomName
                }));

                console.log('✅ Audio enviado');
                updateAudioLog('Audio enviado a conductores');
            } else {
                console.warn('⚠️ WebSocket no disponible');
            }
        };

        reader.readAsDataURL(audioBlob);

    } catch (error) {
        console.error('❌ Error enviando audio:', error);
    }
}

// Agregar audio a la cola de reproducción
function addAudioToQueue(audioData) {
    audioQueue.push(audioData);
    console.log('📋 Audio agregado a cola, total:', audioQueue.length);

    if (!isPlayingAudio) {
        playNextAudio();
    }
}

// Reproducir siguiente audio
async function playNextAudio() {
    if (audioQueue.length === 0) {
        isPlayingAudio = false;
        return;
    }

    isPlayingAudio = true;
    const audioData = audioQueue.shift();

    try {
        console.log('🔊 Reproduciendo audio...');

        // Crear elemento de audio
        const audioPlayer = safeGetElement('audio-player');
        if (!audioPlayer) {
            console.error('❌ Reproductor de audio no encontrado');
            return;
        }

        // Configurar audio
        audioPlayer.src = `data:audio/wav;base64,${audioData.audioData}`;

        // Eventos de reproducción
        audioPlayer.onended = () => {
            console.log('✅ Audio terminado');
            isPlayingAudio = false;
            playNextAudio(); // Reproducir siguiente
        };

        audioPlayer.onerror = (error) => {
            console.error('❌ Error reproduciendo audio:', error);
            isPlayingAudio = false;
            playNextAudio(); // Continuar con siguiente
        };

        // Reproducir
        await audioPlayer.play();

    } catch (error) {
        console.error('❌ Error en reproducción:', error);
        isPlayingAudio = false;
        playNextAudio(); // Continuar con siguiente
    }
}

// Actualizar log de audio
function updateAudioLog(message) {
    try {
        const audioLog = document.getElementById('audio-log');
        if (!audioLog) {
            console.warn('⚠️ audio-log no encontrado');
            return;
        }

        // Eliminar placeholder si existe
        const placeholder = audioLog.querySelector('.audio-log-empty');
        if (placeholder) {
            placeholder.remove();
        }

        // Crear entrada de log
        const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
        const logEntry = document.createElement('div');
        logEntry.className = 'audio-log-entry';
        logEntry.style.cssText = 'padding: 8px 12px; margin-bottom: 5px; background: rgba(255,255,255,0.05); border-left: 3px solid #4CAF50; border-radius: 4px; font-size: 0.9rem;';
        logEntry.innerHTML = `<span style="color: #888;">[${timestamp}]</span> ${message}`;

        // Agregar al inicio del log
        audioLog.insertBefore(logEntry, audioLog.firstChild);

        // Mantener solo las últimas 50 entradas
        const entries = audioLog.querySelectorAll('.audio-log-entry');
        if (entries.length > 50) {
            entries[entries.length - 1].remove();
        }

        console.log('✅ Log de audio actualizado:', message);
    } catch (error) {
        console.error('❌ Error actualizando log:', error);
    }
}

// Configurar eventos de click en la lista de conductores
function setupDriverListEvents() {
    console.log('🔧 Configurando eventos de la lista de conductores...');

    const driverItems = document.querySelectorAll('.user-item[data-driver-id]');
    console.log(`📋 Encontrados ${driverItems.length} elementos de conductor`);

    driverItems.forEach(item => {
        const driverId = item.getAttribute('data-driver-id');
        const driverName = item.getAttribute('data-driver-name') ||
            item.querySelector('span')?.textContent ||
            `Conductor #${driverId}`;

        // Remover eventos anteriores
        item.replaceWith(item.cloneNode(true));
        const newItem = document.querySelector(`[data-driver-id="${driverId}"]`);

        if (newItem) {
            newItem.addEventListener('click', function () {
                console.log(`💬 Click en conductor: ${driverName} (ID: ${driverId})`);
                openDriverChatFromList(driverId, driverName);
            });

            // Estilo cursor
            newItem.style.cursor = 'pointer';

            console.log(`✅ Evento configurado para conductor: ${driverName}`);
        }
    });
}

// Inicialización principal
async function initSystem() {
    if (systemInitialized) {
        console.log('⚠️ Sistema ya inicializado');
        return;
    }

    console.log('� Iniciando sistema completo...');

    try {
        // Asegurar elementos requeridos
        ensureRequiredElements();

        // Inicializar componentes
        updateStatus('Inicializando...', 'connecting');

        // Cargar Google Maps
        await loadGoogleMapsAPI();

        // Configurar WebSocket
        setupWebSocket();

        // Configurar sistema de audio
        setupAudioSystem();

        // Configurar eventos de la lista de conductores
        setupDriverListEvents();

        systemInitialized = true;
        updateStatus('Sistema listo', 'connected');
        console.log('✅ Sistema inicializado completamente');

    } catch (error) {
        console.error('❌ Error inicializando sistema:', error);
        updateStatus('Error en inicialización', 'error');
    }
}

// Función específica para abrir chat desde la lista lateral
function openDriverChatFromList(driverId, driverName) {
    console.log('💬 Abriendo chat desde lista lateral:', driverName, 'ID:', driverId);

    try {
        // Actualizar el header del chat
        const chatHeader = document.getElementById('chat-header');
        if (chatHeader) {
            chatHeader.innerHTML = `
                <span>💬 Chat con: ${driverName}</span>
                <div class="header-controls">
                    <button class="header-toggle-btn" id="toggle-fullscreen" onclick="toggleFullscreen()" title="Pantalla completa (F11)">🔳</button>
                    <button class="header-toggle-btn minimize" onclick="toggleChat()" title="Ocultar chat (Ctrl+H)">✕</button>
                </div>
            `;
        }

        // Limpiar mensajes anteriores y mostrar el chat
        const chatLog = document.getElementById('chat-log');
        if (chatLog) {
            chatLog.innerHTML = `
                <div style="text-align: center; padding: 20px; color: #7f8c8d; border-bottom: 1px solid #eee;">
                    <strong>💬 Chat iniciado con ${driverName}</strong><br>
                    <small>Los mensajes aparecerán aquí en tiempo real...</small>
                </div>
            `;
        }

        // Mostrar el área de entrada de mensaje
        const inputContainer = document.getElementById('chat-input-container');
        if (inputContainer) {
            inputContainer.style.display = 'flex';
        }

        // Ocultar el mensaje de "no chat seleccionado"
        const noChatSelected = document.getElementById('no-chat-selected');
        if (noChatSelected) {
            noChatSelected.style.display = 'none';
        }

        // Configurar el input para este conductor
        const messageInput = document.getElementById('chat-message-input');
        if (messageInput) {
            messageInput.setAttribute('data-driver-id', driverId);
            messageInput.placeholder = `Escribe un mensaje a ${driverName}...`;
            messageInput.focus();
        }

        // Configurar el botón de envío - clonar para remover eventos anteriores
        const submitButton = document.getElementById('chat-message-submit');
        if (submitButton) {
            const newSubmitButton = submitButton.cloneNode(true);
            submitButton.parentNode.replaceChild(newSubmitButton, submitButton);

            newSubmitButton.addEventListener('click', function () {
                sendMessageToDriver(driverId);
            });
        }

        // Configurar Enter en el input - clonar para remover eventos anteriores
        if (messageInput) {
            const newInput = messageInput.cloneNode(true);
            messageInput.parentNode.replaceChild(newInput, messageInput);

            newInput.addEventListener('keypress', function (e) {
                if (e.key === 'Enter') {
                    sendMessageToDriver(driverId);
                }
            });
        }

        // Hacer visible el chat window si está oculto
        const chatWindow = document.querySelector('.chat-window');
        if (chatWindow) {
            chatWindow.classList.remove('hidden');
        }

        // Resaltar el elemento seleccionado
        document.querySelectorAll('.user-item').forEach(item => {
            item.classList.remove('active');
        });
        document.querySelector(`[data-driver-id="${driverId}"]`)?.classList.add('active');

        console.log(`✅ Chat iniciado desde lista: ${driverName} (ID: ${driverId})`);

    } catch (error) {
        console.error('❌ Error abriendo chat desde lista:', error);
        alert('Error abriendo el chat. Por favor, intenta de nuevo.');
    }
}

// Inicialización cuando DOM esté listo
document.addEventListener('DOMContentLoaded', function () {
    console.log('🚀 DOM LISTO - Iniciando sistema completo...');

    // Pequeña pausa para asegurar que todo esté cargado
    setTimeout(() => {
        initSystem();
    }, 500);
});

// Exponer funciones globales
window.openDriverChat = openDriverChat;
window.sendChatMessage = sendChatMessage;

console.log('📝 comunicacion-completa.js cargado completamente');